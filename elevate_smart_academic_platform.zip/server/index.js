import express from "express";
import cors from "cors";
import session from "express-session";
import dotenv from "dotenv";
import { pool } from "./db.js";

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "dev-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 1000 * 60 * 60 * 8 }
}));

const requireAuth = (req, res, next) => req.session.user ? next() : res.status(401).json({ error: "Please sign in again." });
const requireRole = (...roles) => (req, res, next) =>
  req.session.user && roles.includes(req.session.user.role) ? next() : res.status(403).json({ error: "Not allowed." });

app.post("/api/login", async (req, res) => {
  const { loginId, password, role } = req.body;
  if (!loginId || !password || !["student","teacher","parent","admin"].includes(role))
    return res.status(400).json({ error: "Enter your ID, password and account type." });
  try {
    const [rows] = await pool.query(
      "SELECT id, login_id, password_hash, full_name, role, programme, semester FROM users WHERE login_id=? AND role=?",
      [loginId, role]
    );
    if (!rows.length) return res.status(401).json({ error: "Those details don't match this account." });
    // Replace this comparison with bcrypt.compare after creating password hashes.
    const valid = rows[0].password_hash === password;
    if (!valid) return res.status(401).json({ error: "Those details don't match this account." });
    const { password_hash, ...safeUser } = rows[0];
    req.session.user = safeUser;
    res.json({ user: safeUser });
  } catch (e) { res.status(500).json({ error: "Database connection issue." }); }
});

app.get("/api/me", requireAuth, (req,res) => res.json({ user: req.session.user }));
app.post("/api/logout", requireAuth, (req,res) => req.session.destroy(() => res.json({ ok: true })));

app.get("/api/parent/ward/:id/summary", requireAuth, requireRole("parent"), async (req,res) => {
  try {
    const wardId = Number(req.params.id);
    const [link] = await pool.query("SELECT 1 FROM parent_student WHERE parent_id=? AND student_id=?", [req.session.user.id, wardId]);
    if (!link.length) return res.status(403).json({ error: "This student is not linked to your account." });
    const [[attendance]] = await pool.query(
      `SELECT COUNT(*) total, SUM(status='present') present, SUM(status='absent') absent
       FROM attendance WHERE student_id=? AND class_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')`, [wardId]);
    const [courses] = await pool.query(
      `SELECT s.title FROM enrollments e JOIN subjects s ON s.id=e.subject_id WHERE e.student_id=?`, [wardId]);
    const [tasks] = await pool.query(
      `SELECT a.title, COALESCE(sub.status,'not_started') status, a.due_at
       FROM assignments a JOIN enrollments e ON e.subject_id=a.subject_id
       LEFT JOIN submissions sub ON sub.assignment_id=a.id AND sub.student_id=e.student_id
       WHERE e.student_id=? ORDER BY a.due_at`, [wardId]);
    const total = Number(attendance.total || 0), present = Number(attendance.present || 0);
    res.json({ attendance: { total, present, absent: Number(attendance.absent || 0), percent: total ? Math.round(present/total*100) : 0 }, courses, tasks });
  } catch { res.status(500).json({ error: "Could not load the ward summary." }); }
});

app.post("/api/parent/feedback", requireAuth, requireRole("parent"), async (req,res) => {
  const { studentId, message } = req.body;
  const [link] = await pool.query("SELECT 1 FROM parent_student WHERE parent_id=? AND student_id=?", [req.session.user.id, studentId]);
  if (!link.length) return res.status(403).json({ error: "Not linked to this student." });
  await pool.query("INSERT INTO parent_feedback(parent_id,student_id,message) VALUES(?,?,?)", [req.session.user.id, studentId, message]);
  res.json({ ok: true });
});

app.get("/api/student/subjects", requireAuth, requireRole("student"), async (req,res) => {
  const [rows] = await pool.query(
    "SELECT s.* FROM subjects s JOIN enrollments e ON e.subject_id=s.id WHERE e.student_id=? ORDER BY s.semester,s.title",
    [req.session.user.id]);
  res.json({ subjects: rows });
});

app.get("/api/health", (_req,res) => res.json({ ok: true, app: "Elevate API" }));
const port = process.env.PORT || 5000;
app.listen(port, () => console.log(`Elevate API running on ${port}`));

# Elevate — Smart Academic Learning & Placement Readiness Platform

A polished full-stack starter for a college project. The included UI is a working role-based demo; the Express/MySQL backend and schema provide the foundation for real institutional data.

## 1. Requirements
- Node.js 18+
- MySQL 8+
- VS Code (recommended)

## 2. Run the website
```bash
npm install
npm run dev
```
Open the Vite URL shown in the terminal (normally http://localhost:5173).

## 3. Demo logins
The front-end demo uses these credentials and stores the signed-in role in `sessionStorage` (so closing the tab/window ends the demo session):

| Role | Login ID | Password |
|---|---|---|
| Student | STU24018 | learn123 |
| Teacher | TCH1007 | teach123 |
| Parent | PAR5002 | parent123 |
| Admin | ADMIN01 | admin123 |

These are demo-only credentials. Do not use them in production.

## 4. MySQL setup
1. Create a database by running `database/schema.sql` in MySQL Workbench or the MySQL CLI.
2. Copy `.env.example` to `.env` and enter your local MySQL credentials.
3. Install dependencies with `npm install`.
4. Start the API with `npm run server` (port 5000).

The API currently includes login/session endpoints, parent-authorised ward summary and feedback endpoints, and enrolled-subject retrieval. Seed institution-specific users, programmes, subjects, lessons, assignments, RFID attendance events and parent/student links before using real data.

## 5. Important implementation notes
- **Authentication:** the demo UI is not production authentication. The API login currently uses a clearly marked development password comparison. Replace it with `bcrypt` password hashing, rate limiting, CSRF protection, secure HTTPS cookies, account recovery and audit logs before deployment.
- **Logout:** the front-end demo uses `sessionStorage`, which clears when the tab/session ends. Production session cookies should use appropriate expiry and server-side session storage.
- **Learning gates:** the UI demonstrates the requested rule: a new assignment is unlocked only when theory completion is at least 80% AND quiz score is at least 60%. Build server-side checks for all lesson and assignment access; never trust client-side state.
- **Video progress:** for accurate video progress, use a player API and record watched intervals on the server. Do not count seeking to the end as completion.
- **AI lesson helper:** the UI demonstrates a constrained concept-help chat placeholder. Connect it to an approved AI endpoint with lesson context and guardrails that refuse summaries, quiz answers and assignment solutions.
- **Quizzes:** objective questions can be auto-scored deterministically. Descriptive responses should be reviewed by faculty or a separately validated rubric workflow; do not blindly trust generative AI marks.
- **Parent access:** parent endpoints check the parent/student relationship and return summary data only. Extend this with explicit field-level permissions and audit logging.
- **RFID attendance:** the database supports RFID-sourced attendance. Your hardware integration can POST verified card scans to a protected endpoint later. Never expose raw RFID credentials or allow student-side attendance edits.
- **No browsing lock:** a normal website cannot reliably prevent a student from opening other websites or apps. For supervised assessments, use institution-managed kiosk/lockdown browser software, managed devices and clear consent. Do not attempt covert device monitoring.
- **Current internships:** links are starting points, not verified live openings. Check eligibility, deadlines and authenticity on the official listing before applying.
- **Programme syllabus:** the sample syllabus is illustrative. The actual subjects must be imported from the institution's approved curriculum and filtered by programme, semester and enrolment.

## 6. Suggested next build milestones
1. Add bcrypt-based account creation, seeded users and admin CRUD.
2. Build teacher upload/review APIs and student submission flows.
3. Add video-player progress events and server-side unlock rules.
4. Add quiz bank, attempt history, scorecards and revision scheduling.
5. Connect RFID device/controller feed and monthly attendance notifications.
6. Add programme-specific curriculum tables for B.Tech, BCA, BBA, Polytechnic, Mechanical, Electrical and other departments.
7. Connect a restricted AI lesson assistant and resume feedback service.
8. Add production deployment, backups, privacy policy and accessibility testing.
